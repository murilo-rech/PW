package br.edu.ifsul.projetofinalpdm;

public class Atendimento {
    private String aluno;
    private String professor;
    private String materia;
    private String data;
    private String horario;
    private String assunto;
    private String status;
    private String disponibilidadeId;
    private String modalidade;
    private String local;
    private String codigoEscola;

    public Atendimento(String aluno, String professor, String materia, String data,
                     String horario, String assunto, String status,
                     String disponibilidadeId, String modalidade, String local,
                     String codigoEscola) {
        this.aluno = aluno;
        this.professor = professor;
        this.materia = materia;
        this.data = data;
        this.horario = horario;
        this.assunto = assunto;
        this.status = status;
        this.disponibilidadeId = disponibilidadeId;
        this.modalidade = modalidade;
        this.local = local;
        this.codigoEscola = codigoEscola;
    }

    public String getAluno() { return aluno == null ? "" : aluno; }
    public String getProfessor() { return professor == null ? "" : professor; }
    public String getMateria() { return materia == null ? "" : materia; }
    public String getData() { return data == null ? "" : data; }
    public String getHorario() { return horario == null ? "" : horario; }
    public String getAssunto() { return assunto == null ? "" : assunto; }
    public String getStatus() { return status == null ? "Aguardando confirmação" : status; }
    public String getDisponibilidadeId() { return disponibilidadeId == null ? "" : disponibilidadeId; }
    public String getModalidade() { return modalidade == null ? "" : modalidade; }
    public String getLocal() { return local == null ? "" : local; }
    public String getCodigoEscola() { return codigoEscola == null ? "" : codigoEscola; }
    public void setStatus(String status) { this.status = status; }
    public void setAluno(String aluno) { this.aluno = aluno; }
    public void setProfessor(String professor) { this.professor = professor; }
}

