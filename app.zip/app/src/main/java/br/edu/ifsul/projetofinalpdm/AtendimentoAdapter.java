package br.edu.ifsul.projetofinalpdm;

import android.app.AlertDialog;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;

public class AtendimentoAdapter extends RecyclerView.Adapter<AtendimentoAdapter.ViewHolder> {
    private final Context context;
    private final ArrayList<Atendimento> lista;
    private final boolean professor;
    private final boolean escola;

    public AtendimentoAdapter(Context context, ArrayList<Atendimento> lista, boolean professor, boolean escola) {
        this.context = context;
        this.lista = lista;
        this.professor = professor;
        this.escola = escola;
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        TextView titulo, data, materia, aluno, assunto, status;
        ViewHolder(View view) {
            super(view);
            titulo = view.findViewById(R.id.txtNomePessoa);
            data = view.findViewById(R.id.txtDataAtendimento);
            materia = view.findViewById(R.id.txtMateriaAtendimento);
            aluno = view.findViewById(R.id.txtAlunoAtendimento);
            assunto = view.findViewById(R.id.txtAssuntoAtendimento);
            status = view.findViewById(R.id.btnVerDetalhes);
        }
    }

    @NonNull @Override public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_atendimento, parent, false);
        return new ViewHolder(view);
    }

    @Override public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Atendimento item = lista.get(position);
        holder.titulo.setText(professor ? item.getAluno() : item.getProfessor());
        holder.data.setText(item.getData() + " as " + item.getHorario());
        holder.materia.setText("Materia: " + item.getMateria());
        holder.aluno.setVisibility(escola ? View.VISIBLE : View.GONE);
        holder.aluno.setText("Aluno: " + item.getAluno());
        holder.assunto.setText("Assunto: " + item.getAssunto()
                + "\nModalidade: " + item.getModalidade()
                + "\nLocal: " + item.getLocal());
        holder.status.setText(professor ? "Atualizar: " + item.getStatus() : item.getStatus());
        if (professor) holder.status.setOnClickListener(v -> new AlertDialog.Builder(context)
                .setTitle("Atualizar atendimento")
                .setItems(new String[]{"Confirmar", "Recusar", "Concluir"}, (dialog, escolha) -> {
                    String[] estados = {"Confirmado", "Recusado", "Concluido"};
                    item.setStatus(estados[escolha]);
                    AtendimentoStorage.salvar(context, lista);
                    int indice = holder.getBindingAdapterPosition();
                    if (indice != RecyclerView.NO_POSITION) notifyItemChanged(indice);
                }).show());
        else holder.status.setOnClickListener(null);
    }

    @Override public int getItemCount() { return lista.size(); }
}
