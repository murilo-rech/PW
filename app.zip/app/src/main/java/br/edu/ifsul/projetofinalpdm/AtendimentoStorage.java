package br.edu.ifsul.projetofinalpdm;

import android.content.Context;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;
import java.util.ArrayList;

public final class AtendimentoStorage {
    private AtendimentoStorage() { }
    public static ArrayList<Atendimento> carregar(Context context) {
        String json = context.getSharedPreferences("atendimentos", Context.MODE_PRIVATE)
                .getString("lista", "[]");
        Type tipo = new TypeToken<ArrayList<Atendimento>>() {}.getType();
        try {
            ArrayList<Atendimento> lista = new Gson().fromJson(json, tipo);
            return lista == null ? new ArrayList<>() : lista;
        } catch (RuntimeException erro) {
            return new ArrayList<>();
        }
    }
    public static void salvar(Context context, ArrayList<Atendimento> lista) {
        context.getSharedPreferences("atendimentos", Context.MODE_PRIVATE).edit()
                .putString("lista", new Gson().toJson(lista)).apply();
    }
}

