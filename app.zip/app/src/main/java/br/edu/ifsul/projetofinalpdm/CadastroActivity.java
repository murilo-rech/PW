package br.edu.ifsul.projetofinalpdm;

import android.content.Intent;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class CadastroActivity extends AppCompatActivity {
    private EditText edtNome, edtEmail, edtSenha, edtConfirmarSenha;
    private EditText edtCodigoEscola, edtArea, edtDisciplinas, edtInstituicao;
    private RadioGroup grupoPerfil;
    private String perfilInicial;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastro);

        edtNome = findViewById(R.id.edtNomeCadastro);
        edtEmail = findViewById(R.id.edtEmailCadastro);
        edtSenha = findViewById(R.id.edtSenhaCadastro);
        edtConfirmarSenha = findViewById(R.id.edtConfirmarSenha);
        edtCodigoEscola = findViewById(R.id.edtCodigoEscola);
        edtArea = findViewById(R.id.edtAreaProfessor);
        edtDisciplinas = findViewById(R.id.edtDisciplinasProfessor);
        edtInstituicao = findViewById(R.id.edtInstituicao);
        grupoPerfil = findViewById(R.id.grupoPerfilCadastro);
        perfilInicial = getIntent().getStringExtra("perfil");
        if ("professor".equals(perfilInicial)) grupoPerfil.check(R.id.rbPerfilProfessor);
        else if ("escola".equals(perfilInicial)) grupoPerfil.check(R.id.rbPerfilEscola);
        else grupoPerfil.check(R.id.rbPerfilAluno);
        grupoPerfil.setOnCheckedChangeListener((group, checkedId) -> atualizarCamposPerfil());
        atualizarCamposPerfil();
        findViewById(R.id.btnCadastrar).setOnClickListener(v -> cadastrar());
        findViewById(R.id.txtIrLogin).setOnClickListener(v -> abrirLogin());
        findViewById(R.id.btnVoltarCadastro).setOnClickListener(v -> finish());
    }

    private void cadastrar() {
        String nome = edtNome.getText().toString().trim();
        String email = edtEmail.getText().toString().trim();
        String senha = edtSenha.getText().toString();
        String confirmacao = edtConfirmarSenha.getText().toString();
        String perfil = perfilSelecionado();
        String codigoEscola = UsuarioStorage.normalizarCodigoEscola(
                edtCodigoEscola.getText().toString());
        String instituicao = edtInstituicao.getText().toString().trim();
        if (nome.isEmpty() || email.isEmpty() || senha.isEmpty() || confirmacao.isEmpty()) {
            Toast.makeText(this, "Preencha todos os campos", Toast.LENGTH_SHORT).show();
        } else if (!android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            Toast.makeText(this, "Digite um email válido", Toast.LENGTH_SHORT).show();
        } else if (senha.length() < 6) {
            Toast.makeText(this, "A senha deve ter no mínimo 6 caracteres", Toast.LENGTH_SHORT).show();
        } else if (!senha.equals(confirmacao)) {
            Toast.makeText(this, "As senhas não coincidem", Toast.LENGTH_SHORT).show();
        } else if (codigoEscola.isEmpty()) {
            Toast.makeText(this, perfil.equals("escola")
                    ? "Crie um código para sua escola"
                    : "Informe o código fornecido pela escola", Toast.LENGTH_SHORT).show();
        } else if (!UsuarioStorage.formatoCodigoEscolaValido(codigoEscola)) {
            Toast.makeText(this,
                    "Use de 4 a 30 letras ou números. Hífens são permitidos.",
                    Toast.LENGTH_LONG).show();
        } else if (perfil.equals("escola") && instituicao.isEmpty()) {
            Toast.makeText(this, "Informe o nome da instituição", Toast.LENGTH_SHORT).show();
        } else if (perfil.equals("escola")
                && UsuarioStorage.codigoEscolaEmUso(this, codigoEscola)) {
            Toast.makeText(this, "Esse código já pertence a outra escola. Escolha outro.",
                    Toast.LENGTH_LONG).show();
        } else if (!perfil.equals("escola")
                && UsuarioStorage.buscarEscolaPorCodigo(this, codigoEscola) == null) {
            Toast.makeText(this, "Código não encontrado. Confira com a escola.",
                    Toast.LENGTH_LONG).show();
        } else if (UsuarioStorage.existe(this, email)) {
            Toast.makeText(this, "Já existe uma conta com esse email", Toast.LENGTH_LONG).show();
        } else {
            Usuario escola = perfil.equals("escola") ? null
                    : UsuarioStorage.buscarEscolaPorCodigo(this, codigoEscola);
            String instituicaoVinculada = perfil.equals("escola") ? instituicao
                    : escola.getInstituicao();
            Usuario usuario = new Usuario(nome, email, senha, perfil, codigoEscola,
                    edtArea.getText().toString().trim(), edtDisciplinas.getText().toString().trim(),
                    instituicaoVinculada);
            if (UsuarioStorage.salvar(this, usuario, "")) {
                Toast.makeText(this, "Conta criada. Entre com seu email e senha.", Toast.LENGTH_LONG).show();
                Intent tela = new Intent(this, LoginActivity.class);
                tela.putExtra("perfil", perfil);
                tela.putExtra("email", email);
                startActivity(tela);
                finish();
            } else {
                Toast.makeText(this, "Não foi possível criar a conta. Tente outro email.",
                        Toast.LENGTH_LONG).show();
            }
        }
    }

    private void atualizarCamposPerfil() {
        String perfil = perfilSelecionado();
        TextView rotuloCodigo = findViewById(R.id.txtLabelCodigoEscola);
        TextView ajudaCodigo = findViewById(R.id.txtAjudaCodigoEscola);
        if (perfil.equals("escola")) {
            rotuloCodigo.setText("Crie o código da escola");
            edtCodigoEscola.setHint("Ex.: IFSUL-PEL-2026");
            ajudaCodigo.setText("Compartilhe este código com alunos e professores. Ele identifica sua instituição.");
        } else {
            rotuloCodigo.setText("Código da escola");
            edtCodigoEscola.setHint("Código fornecido pela escola");
            ajudaCodigo.setText(perfil.equals("professor")
                    ? "A escola revisará seu pedido de vínculo antes do primeiro acesso."
                    : "Peça o código ao administrador da sua instituição.");
        }
        findViewById(R.id.blocoProfessor).setVisibility(
                perfil.equals("professor") ? android.view.View.VISIBLE : android.view.View.GONE);
        findViewById(R.id.blocoEscola).setVisibility(
                perfil.equals("escola") ? android.view.View.VISIBLE : android.view.View.GONE);
    }

    private String perfilSelecionado() {
        int selecionado = grupoPerfil.getCheckedRadioButtonId();
        if (selecionado == R.id.rbPerfilProfessor) return "professor";
        if (selecionado == R.id.rbPerfilEscola) return "escola";
        return "aluno";
    }

    private void abrirLogin() {
        Intent tela = new Intent(this, LoginActivity.class);
        String perfil = perfilSelecionado();
        tela.putExtra("perfil", perfil);
        startActivity(tela);
        finish();
    }
}
