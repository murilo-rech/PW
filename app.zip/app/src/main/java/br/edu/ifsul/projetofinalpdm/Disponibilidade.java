package br.edu.ifsul.projetofinalpdm;

public class Disponibilidade {
    private String id;
    private String professor;
    private String materia;
    private String data;
    private String inicio;
    private String fim;
    private int vagas;
    private String modalidade;
    private String local;
    private String codigoEscola;

    public Disponibilidade(String id, String professor, String materia, String data,
                           String inicio, String fim, int vagas, String modalidade, String local,
                           String codigoEscola) {
        this.id = id;
        this.professor = professor;
        this.materia = materia;
        this.data = data;
        this.inicio = inicio;
        this.fim = fim;
        this.vagas = vagas;
        this.modalidade = modalidade;
        this.local = local;
        this.codigoEscola = codigoEscola;
    }

    public String getId() { return id == null ? "" : id; }
    public String getProfessor() { return professor == null ? "" : professor; }
    public String getMateria() { return materia == null ? "" : materia; }
    public String getData() { return data == null ? "" : data; }
    public String getInicio() { return inicio == null ? "" : inicio; }
    public String getFim() { return fim == null ? "" : fim; }
    public int getVagas() { return vagas; }
    public String getModalidade() { return modalidade == null ? "" : modalidade; }
    public String getLocal() { return local == null ? "" : local; }
    public String getCodigoEscola() { return codigoEscola == null ? "" : codigoEscola; }
    public void setProfessor(String professor) { this.professor = professor; }

    @Override public String toString() {
        return data + " | " + inicio + "–" + fim;
    }
}
