package br.edu.ifsul.projetofinalpdm;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;

public class DisponibilidadeAdapter extends RecyclerView.Adapter<DisponibilidadeAdapter.ViewHolder> {
    private final Context context;
    private final ArrayList<Disponibilidade> lista;
    private final ArrayList<Atendimento> atendimentos;
    private final TextView vazio;

    public DisponibilidadeAdapter(Context context, ArrayList<Disponibilidade> lista,
                                  ArrayList<Atendimento> atendimentos, TextView vazio) {
        this.context = context;
        this.lista = lista;
        this.atendimentos = atendimentos;
        this.vazio = vazio;
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        TextView materia, data, professor, detalhes, remover;
        ViewHolder(View view) {
            super(view);
            materia = view.findViewById(R.id.txtMateriaDisponibilidade);
            data = view.findViewById(R.id.txtDataDisponibilidade);
            professor = view.findViewById(R.id.txtProfessorDisponibilidade);
            detalhes = view.findViewById(R.id.txtDetalhesDisponibilidade);
            remover = view.findViewById(R.id.btnRemoverDisponibilidade);
        }
    }

    @NonNull @Override public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_disponibilidade, parent, false);
        return new ViewHolder(view);
    }

    @Override public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Disponibilidade item = lista.get(position);
        int ocupadas = 0;
        for (Atendimento atendimento : atendimentos) {
            if (atendimento.getDisponibilidadeId().equals(item.getId())
                    && !atendimento.getStatus().equals("Recusado")) ocupadas++;
        }
        int restantes = Math.max(0, item.getVagas() - ocupadas);
        holder.materia.setText(item.getMateria());
        holder.data.setText(item.getData() + "  •  " + item.getInicio() + "–" + item.getFim());
        holder.professor.setText("Professor: " + item.getProfessor());
        holder.detalhes.setText(item.getModalidade() + "  •  " + item.getLocal()
                + "\n" + restantes + (restantes == 1 ? " vaga disponível" : " vagas disponíveis"));
        holder.remover.setOnClickListener(v -> {
            int indice = holder.getBindingAdapterPosition();
            if (indice != RecyclerView.NO_POSITION) {
                lista.remove(indice);
                DisponibilidadeStorage.salvar(context, lista);
                notifyItemRemoved(indice);
                vazio.setVisibility(lista.isEmpty() ? View.VISIBLE : View.GONE);
            }
        });
    }

    @Override public int getItemCount() { return lista.size(); }
}
