package br.edu.ifsul.projetofinalpdm;

import android.content.Context;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;
import java.util.ArrayList;

public final class DisponibilidadeStorage {
    private DisponibilidadeStorage() { }

    public static ArrayList<Disponibilidade> carregar(Context context) {
        String json = context.getSharedPreferences("disponibilidades", Context.MODE_PRIVATE)
                .getString("lista", "[]");
        Type tipo = new TypeToken<ArrayList<Disponibilidade>>() { }.getType();
        try {
            ArrayList<Disponibilidade> lista = new Gson().fromJson(json, tipo);
            return lista == null ? new ArrayList<>() : lista;
        } catch (RuntimeException erro) {
            return new ArrayList<>();
        }
    }

    public static void salvar(Context context, ArrayList<Disponibilidade> lista) {
        context.getSharedPreferences("disponibilidades", Context.MODE_PRIVATE).edit()
                .putString("lista", new Gson().toJson(lista)).apply();
    }
}
