package br.edu.ifsul.projetofinalpdm;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;

public class HistoricoActivity extends AppCompatActivity {
    private AtendimentoAdapter adapter;
    private ArrayList<Atendimento> lista;
    private String perfil;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_historico);
        perfil = getSharedPreferences("eduschedule", MODE_PRIVATE).getString("perfil", "aluno");
        TextView titulo = findViewById(R.id.txtTituloHeader);
        TextView descricao = findViewById(R.id.txtDescricaoHistorico);
        View botaoAgendar = findViewById(R.id.btnAgendarAtendimento);
        if (perfil.equals("professor")) {
            titulo.setText("Solicitações recebidas");
            descricao.setText("Consulte os pedidos e atualize o status de cada atendimento.");
            botaoAgendar.setVisibility(View.GONE);
        } else if (perfil.equals("escola")) {
            titulo.setText("Atendimentos da escola");
            descricao.setText("Acompanhe os agendamentos feitos na instituição.");
            botaoAgendar.setVisibility(View.GONE);
        } else {
            titulo.setText("Meus atendimentos");
            descricao.setText("Acompanhe suas solicitações e confirmações.");
            botaoAgendar.setOnClickListener(v ->
                    startActivity(new Intent(this, NovaAtendimentoActivity.class)));
        }

        RecyclerView recycler = findViewById(R.id.rvMeusAtendimentos);
        lista = new ArrayList<>();
        adapter = new AtendimentoAdapter(this, lista, perfil.equals("professor"), perfil.equals("escola"));
        recycler.setLayoutManager(new LinearLayoutManager(this));
        recycler.setAdapter(adapter);
        findViewById(R.id.btnVoltar).setOnClickListener(v -> finish());
        configurarNavegacao();
    }

    @Override protected void onResume() {
        super.onResume();
        lista.clear();
        String nome = getSharedPreferences("eduschedule", MODE_PRIVATE).getString("nome", "");
        String codigoEscola = getSharedPreferences("eduschedule", MODE_PRIVATE)
                .getString("codigoEscola", "");
        for (Atendimento item : AtendimentoStorage.carregar(this)) {
            if (!item.getCodigoEscola().equalsIgnoreCase(codigoEscola)) continue;
            if (perfil.equals("escola")
                    || (perfil.equals("professor") && item.getProfessor().equalsIgnoreCase(nome))
                    || (perfil.equals("aluno") && (nome.isEmpty() || item.getAluno().equalsIgnoreCase(nome)))) {
                lista.add(item);
            }
        }
        adapter.notifyDataSetChanged();
    }

    private void configurarNavegacao() {
        findViewById(R.id.navInicio).setOnClickListener(v ->
                startActivity(new Intent(this, MainActivity.class)));
        View navAgendar = findViewById(R.id.navAgendar);
        View navProfessor = findViewById(R.id.navResultados);
        View navEscola = findViewById(R.id.navPerfil);
        if (perfil.equals("aluno")) {
            navProfessor.setVisibility(View.GONE);
            navEscola.setVisibility(View.GONE);
            navAgendar.setOnClickListener(v -> startActivity(
                    new Intent(this, NovaAtendimentoActivity.class)));
        } else if (perfil.equals("professor")) {
            navAgendar.setVisibility(View.GONE);
            navEscola.setVisibility(View.GONE);
            navProfessor.setOnClickListener(v -> startActivity(
                    new Intent(this, ResultadosActivity.class)));
        } else {
            navAgendar.setVisibility(View.GONE);
            navProfessor.setVisibility(View.GONE);
            ((TextView) navEscola).setText("Perfil");
        }
        findViewById(R.id.navHistorico).setOnClickListener(v -> { });
        navEscola.setOnClickListener(v -> startActivity(
                new Intent(this, MeuPerfilActivity.class)));
        ((TextView) findViewById(R.id.navHistorico)).setTextColor(getColor(R.color.green));
        if (perfil.equals("aluno")) {
            ((TextView) navAgendar).setText("Agendar");
            ((TextView) findViewById(R.id.navHistorico)).setText("Meus");
        } else if (perfil.equals("professor")) {
            ((TextView) navProfessor).setText("Horários");
            ((TextView) findViewById(R.id.navHistorico)).setText("Pedidos");
            ((TextView) navEscola).setText("Perfil");
        } else {
            ((TextView) findViewById(R.id.navHistorico)).setText("Pedidos");
            ((TextView) navEscola).setText("Perfil");
        }
    }
}
