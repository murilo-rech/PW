package br.edu.ifsul.projetofinalpdm;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {
    private EditText edtEmail, edtSenha;
    private RadioGroup grupoAcesso;
    private String perfilEsperado;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        perfilEsperado = getIntent().getStringExtra("perfil");
        if (perfilEsperado == null) perfilEsperado = "";
        String rotulo = perfilEsperado.equals("professor") ? "Professor"
                : perfilEsperado.equals("escola") ? "Escola"
                : perfilEsperado.equals("aluno") ? "Aluno" : "EduSchedule";
        ((TextView) findViewById(R.id.txtTituloLogin)).setText(
                rotulo.equals("EduSchedule") ? "Acesse sua conta" : "Acesso " + rotulo);
        ((TextView) findViewById(R.id.txtDescricaoPerfil)).setText(
                "Entre para organizar seus atendimentos acadêmicos.");
        edtEmail = findViewById(R.id.edtEmail);
        edtSenha = findViewById(R.id.edtSenha);
        findViewById(R.id.btnVoltarLogin).setOnClickListener(v -> finish());
        grupoAcesso = findViewById(R.id.grupoTipoAcesso);
        if (perfilEsperado.equals("escola")) grupoAcesso.check(R.id.rbAcessoEscola);
        else grupoAcesso.check(R.id.rbAcessoUsuario);
        String email = getIntent().getStringExtra("email");
        if (email != null) edtEmail.setText(email);

        findViewById(R.id.btnEntrar).setOnClickListener(v -> entrar());
        findViewById(R.id.txtIrCadastro).setOnClickListener(v -> {
            Intent tela = new Intent(this, CadastroActivity.class);
            if (!perfilEsperado.isEmpty()) tela.putExtra("perfil", perfilEsperado);
            startActivity(tela);
        });
        TextView esqueceu = findViewById(R.id.txtEsqueceuSenha);
        esqueceu.setOnClickListener(v -> Toast.makeText(this,
                "Procure a secretaria da escola para redefinir sua senha.", Toast.LENGTH_LONG).show());
    }

    private void entrar() {
        String email = edtEmail.getText().toString().trim();
        String senha = edtSenha.getText().toString();
        if (email.isEmpty() || senha.isEmpty()) {
            Toast.makeText(this, "Preencha email e senha", Toast.LENGTH_SHORT).show();
            return;
        }

        if (!android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            Toast.makeText(this, "Digite um email válido", Toast.LENGTH_SHORT).show();
            return;
        }
        Usuario usuario = UsuarioStorage.buscar(this, email);
        if (usuario == null || !usuario.getSenha().equals(senha)) {
            Toast.makeText(this, "Email ou senha incorretos. Confira os dados ou crie sua conta.",
                    Toast.LENGTH_LONG).show();
            return;
        }
        if (usuario.getPerfil().equals("professor") && !usuario.isAprovado()) {
            Toast.makeText(this, "Seu vínculo com a escola ainda aguarda aprovação.",
                    Toast.LENGTH_LONG).show();
            return;
        }

        boolean acessoEscola = grupoAcesso.getCheckedRadioButtonId() == R.id.rbAcessoEscola;
        boolean contaEscola = usuario.getPerfil().equals("escola");
        if (acessoEscola != contaEscola) {
            Toast.makeText(this, contaEscola
                    ? "Selecione o acesso de administrador da escola."
                    : "Selecione o acesso de aluno ou professor.", Toast.LENGTH_LONG).show();
            return;
        }
        if (!perfilEsperado.isEmpty() && !perfilEsperado.equals(usuario.getPerfil())) {
            Toast.makeText(this, "Essa conta está cadastrada como "
                    + rotulo(usuario.getPerfil()) + ".", Toast.LENGTH_LONG).show();
            return;
        }

        getSharedPreferences("eduschedule", MODE_PRIVATE).edit()
                .putString("perfil", usuario.getPerfil())
                .putString("nome", usuario.getNome())
                .putString("email", email)
                .putString("codigoEscola", usuario.getCodigoEscola())
                .putString("instituicao", usuario.getInstituicao())
                .putString("area", usuario.getArea())
                .putString("disciplinas", usuario.getDisciplinas())
                .apply();

        Class<?> destino = usuario.getPerfil().equals("professor") ? ResultadosActivity.class
                : usuario.getPerfil().equals("escola") ? MeuPerfilActivity.class
                : NovaAtendimentoActivity.class;
        Intent tela = new Intent(this, destino);
        tela.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(tela);
    }

    private String rotulo(String perfil) {
        if (perfil.equals("professor")) return "professor";
        if (perfil.equals("escola")) return "administrador da escola";
        return "aluno";
    }
}
