package br.edu.ifsul.projetofinalpdm;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        configurarAcesso(R.id.btnLandingAluno, "aluno");
        configurarAcesso(R.id.btnLandingProfessor, "professor");
        configurarAcesso(R.id.btnLandingEscola, "escola");
        findViewById(R.id.btnLandingEntrar).setOnClickListener(v -> abrirLogin(""));
        findViewById(R.id.btnLandingCadastro).setOnClickListener(v ->
                startActivity(new Intent(this, CadastroActivity.class)));
    }

    private void configurarAcesso(int botaoId, String perfil) {
        Button botao = findViewById(botaoId);
        botao.setOnClickListener(v -> abrirLogin(perfil));
    }

    private void abrirLogin(String perfil) {
        Intent tela = new Intent(this, LoginActivity.class);
        if (!perfil.isEmpty()) tela.putExtra("perfil", perfil);
        startActivity(tela);
    }
}
