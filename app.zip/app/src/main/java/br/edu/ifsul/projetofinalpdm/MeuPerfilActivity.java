package br.edu.ifsul.projetofinalpdm;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;

public class MeuPerfilActivity extends AppCompatActivity {
    private EditText nome, email, instituicao, senhaAtual, senhaNova, senhaConfirmar;
    private TextView nomeTopo, emailTopo, tipoTopo, iniciais, resumo;
    private TextView codigoEscolaPerfil;
    private Usuario usuario;
    private String emailAtual;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_meu_perfil);

        nome = findViewById(R.id.edtPerfilNome);
        email = findViewById(R.id.edtPerfilEmail);
        instituicao = findViewById(R.id.edtInstituicaoPerfil);
        senhaAtual = findViewById(R.id.edtSenhaAtual);
        senhaNova = findViewById(R.id.edtSenhaNova);
        senhaConfirmar = findViewById(R.id.edtSenhaConfirmar);
        nomeTopo = findViewById(R.id.txtPerfilNome);
        emailTopo = findViewById(R.id.txtPerfilEmail);
        tipoTopo = findViewById(R.id.txtPerfilTipo);
        iniciais = findViewById(R.id.txtPerfilIniciais);
        resumo = findViewById(R.id.txtPerfilResumo);
        codigoEscolaPerfil = findViewById(R.id.txtPerfilCodigoEscola);

        findViewById(R.id.btnSalvarPerfil).setOnClickListener(v -> salvarPerfil());
        findViewById(R.id.btnPerfilVinculos).setOnClickListener(v -> revisarVinculos());
        codigoEscolaPerfil.setOnClickListener(v -> {
            String codigo = codigoEscolaPerfil.getText().toString();
            ClipboardManager clipboard = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
            clipboard.setPrimaryClip(ClipData.newPlainText("Código da escola", codigo));
            Toast.makeText(this, "Código copiado para compartilhar.", Toast.LENGTH_SHORT).show();
        });
        findViewById(R.id.btnPerfilHistorico).setOnClickListener(v ->
                startActivity(new Intent(this, HistoricoActivity.class)));
        findViewById(R.id.btnPerfilSair).setOnClickListener(v -> {
            getSharedPreferences("eduschedule", MODE_PRIVATE).edit().clear().apply();
            Intent tela = new Intent(this, MainActivity.class);
            tela.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(tela);
        });
        configurarNavegacao();
    }

    @Override protected void onResume() {
        super.onResume();
        SharedPreferences sessao = getSharedPreferences("eduschedule", MODE_PRIVATE);
        emailAtual = sessao.getString("email", "");
        usuario = UsuarioStorage.buscar(this, emailAtual);
        String perfil = sessao.getString("perfil", "aluno");
        findViewById(R.id.blocoVinculos).setVisibility(
                perfil.equals("escola") ? View.VISIBLE : View.GONE);
        if (usuario != null) {
            perfil = usuario.getPerfil();
            nome.setText(usuario.getNome());
            email.setText(usuario.getEmail());
            instituicao.setText(usuario.getInstituicao());
            nomeTopo.setText(usuario.getNome());
            emailTopo.setText(usuario.getEmail());
            findViewById(R.id.blocoInstituicaoPerfil).setVisibility(
                    perfil.equals("escola") ? View.VISIBLE : View.GONE);
            codigoEscolaPerfil.setText(usuario.getCodigoEscola());
        } else {
            nome.setText(sessao.getString("nome", ""));
            email.setText(emailAtual);
            nomeTopo.setText(sessao.getString("nome", "Minha conta"));
            emailTopo.setText(emailAtual);
            findViewById(R.id.blocoInstituicaoPerfil).setVisibility(View.GONE);
        }
        tipoTopo.setText(rotulo(perfil));
        iniciais.setText(iniciais(nomeTopo.getText().toString()));
        carregarResumo(perfil, sessao.getString("nome", ""));
        atualizarVinculos();
    }

    private void salvarPerfil() {
        if (usuario == null) {
            Toast.makeText(this, "Não encontramos os dados desta conta. Saia e faça o cadastro novamente.",
                    Toast.LENGTH_LONG).show();
            return;
        }

        String nomeNovo = nome.getText().toString().trim();
        String emailNovo = email.getText().toString().trim();
        String instituicaoNova = instituicao.getText().toString().trim();
        String atual = senhaAtual.getText().toString();
        String nova = senhaNova.getText().toString();
        String confirmacao = senhaConfirmar.getText().toString();
        if (nomeNovo.isEmpty() || emailNovo.isEmpty()) {
            Toast.makeText(this, "Preencha seu nome e email", Toast.LENGTH_SHORT).show();
            return;
        }
        if (!android.util.Patterns.EMAIL_ADDRESS.matcher(emailNovo).matches()) {
            Toast.makeText(this, "Digite um email válido", Toast.LENGTH_SHORT).show();
            return;
        }
        if (usuario.getPerfil().equals("escola") && instituicaoNova.isEmpty()) {
            Toast.makeText(this, "Informe o nome da instituição", Toast.LENGTH_SHORT).show();
            return;
        }
        if ((!atual.isEmpty() || !nova.isEmpty() || !confirmacao.isEmpty())) {
            if (atual.isEmpty() || nova.isEmpty() || confirmacao.isEmpty()) {
                Toast.makeText(this, "Preencha os três campos para trocar a senha", Toast.LENGTH_LONG).show();
                return;
            }
            if (!usuario.getSenha().equals(atual)) {
                Toast.makeText(this, "A senha atual não confere", Toast.LENGTH_SHORT).show();
                return;
            }
            if (nova.length() < 8) {
                Toast.makeText(this, "A nova senha deve ter pelo menos 8 caracteres", Toast.LENGTH_LONG).show();
                return;
            }
            if (!nova.equals(confirmacao)) {
                Toast.makeText(this, "A confirmação da nova senha não confere", Toast.LENGTH_SHORT).show();
                return;
            }
        }

        String senhaSalva = nova.isEmpty() ? usuario.getSenha() : nova;
        Usuario atualizado = new Usuario(nomeNovo, emailNovo, senhaSalva, usuario.getPerfil(),
                usuario.getCodigoEscola(), usuario.getArea(), usuario.getDisciplinas(),
                usuario.getPerfil().equals("escola") ? instituicaoNova : usuario.getInstituicao(),
                usuario.isAprovado());
        if (!UsuarioStorage.salvar(this, atualizado, emailAtual)) {
            Toast.makeText(this, "Já existe uma conta com esse email", Toast.LENGTH_LONG).show();
            return;
        }

        atualizarRegistros(usuario.getPerfil(), usuario.getNome(), nomeNovo,
                usuario.getCodigoEscola());
        getSharedPreferences("eduschedule", MODE_PRIVATE).edit()
                .putString("nome", nomeNovo)
                .putString("email", emailNovo)
                .putString("perfil", usuario.getPerfil())
                .putString("codigoEscola", usuario.getCodigoEscola())
                .putString("instituicao", atualizado.getInstituicao())
                .apply();
        usuario = atualizado;
        emailAtual = emailNovo;
        nomeTopo.setText(nomeNovo);
        emailTopo.setText(emailNovo);
        iniciais.setText(iniciais(nomeNovo));
        senhaAtual.setText("");
        senhaNova.setText("");
        senhaConfirmar.setText("");
        carregarResumo(usuario.getPerfil(), nomeNovo);
        atualizarVinculos();
        Toast.makeText(this, "Perfil atualizado com sucesso", Toast.LENGTH_SHORT).show();
    }

    private void revisarVinculos() {
        String codigo = getSharedPreferences("eduschedule", MODE_PRIVATE)
                .getString("codigoEscola", "");
        ArrayList<Usuario> pendentes = UsuarioStorage.professoresPendentes(this, codigo);
        if (pendentes.isEmpty()) {
            Toast.makeText(this, "Não há professores aguardando aprovação.",
                    Toast.LENGTH_SHORT).show();
            return;
        }
        mostrarSolicitacaoProfessor(pendentes, 0);
    }

    private void mostrarSolicitacaoProfessor(ArrayList<Usuario> pendentes, int indice) {
        if (indice >= pendentes.size()) return;
        Usuario professor = pendentes.get(indice);
        Dialog dialog = new Dialog(this);
        dialog.setContentView(R.layout.dialog_vinculo_professor);
        ((TextView) dialog.findViewById(R.id.txtSolicitacaoNumero)).setText(
                "Solicitação " + (indice + 1) + " de " + pendentes.size());
        ((TextView) dialog.findViewById(R.id.txtSolicitacaoNome)).setText(professor.getNome());
        ((TextView) dialog.findViewById(R.id.txtSolicitacaoEmail)).setText(professor.getEmail());
        ((TextView) dialog.findViewById(R.id.txtSolicitacaoArea)).setText(
                valorOuNaoInformado(professor.getArea()));
        ((TextView) dialog.findViewById(R.id.txtSolicitacaoDisciplinas)).setText(
                valorOuNaoInformado(professor.getDisciplinas()));

        View fechar = dialog.findViewById(R.id.btnFecharSolicitacao);
        View proxima = dialog.findViewById(R.id.btnProximaSolicitacao);
        View aprovar = dialog.findViewById(R.id.btnAprovarSolicitacao);
        fechar.setOnClickListener(v -> dialog.dismiss());
        if (indice + 1 < pendentes.size()) {
            proxima.setVisibility(View.VISIBLE);
            proxima.setOnClickListener(v -> {
                dialog.dismiss();
                mostrarSolicitacaoProfessor(pendentes, indice + 1);
            });
        } else {
            proxima.setVisibility(View.GONE);
        }
        aprovar.setOnClickListener(v -> {
            Usuario registroAtual = UsuarioStorage.buscar(this, professor.getEmail());
            if (registroAtual == null) {
                dialog.dismiss();
                Toast.makeText(this, "Esta solicitação não está mais disponível.",
                        Toast.LENGTH_SHORT).show();
                atualizarVinculos();
                return;
            }
            registroAtual.setAprovado(true);
            if (!UsuarioStorage.salvar(this, registroAtual, registroAtual.getEmail())) {
                Toast.makeText(this, "Não foi possível aprovar o vínculo.", Toast.LENGTH_SHORT).show();
                return;
            }
            dialog.dismiss();
            atualizarVinculos();
            carregarResumo("escola", getSharedPreferences("eduschedule", MODE_PRIVATE)
                    .getString("nome", ""));
            Toast.makeText(this, "Vínculo de " + registroAtual.getNome() + " aprovado.",
                    Toast.LENGTH_SHORT).show();
            ArrayList<Usuario> restantes = UsuarioStorage.professoresPendentes(this,
                    getSharedPreferences("eduschedule", MODE_PRIVATE)
                            .getString("codigoEscola", ""));
            if (!restantes.isEmpty()) mostrarSolicitacaoProfessor(restantes, 0);
        });

        dialog.setCancelable(true);
        dialog.show();
        Window janela = dialog.getWindow();
        if (janela != null) {
            janela.setBackgroundDrawableResource(android.R.color.transparent);
            int largura = (int) (getResources().getDisplayMetrics().widthPixels * 0.90f);
            janela.setLayout(largura, WindowManager.LayoutParams.WRAP_CONTENT);
        }
    }

    private String valorOuNaoInformado(String valor) {
        return valor == null || valor.trim().isEmpty() ? "Não informado" : valor.trim();
    }

    private void atualizarVinculos() {
        if (!getSharedPreferences("eduschedule", MODE_PRIVATE)
                .getString("perfil", "aluno").equals("escola")) return;
        String codigo = getSharedPreferences("eduschedule", MODE_PRIVATE)
                .getString("codigoEscola", "");
        int quantidade = UsuarioStorage.professoresPendentes(this, codigo).size();
        TextView texto = findViewById(R.id.txtProfessoresPendentes);
        texto.setText(quantidade == 0
                ? "Nenhum vínculo aguardando aprovação."
                : quantidade + (quantidade == 1
                        ? " professor aguarda aprovação." : " professores aguardam aprovação."));
    }

    private void atualizarRegistros(String perfil, String nomeAntigo, String nomeNovo,
                                    String codigoEscola) {
        if (nomeAntigo.equals(nomeNovo)) return;
        if (perfil.equals("professor")) {
            ArrayList<Disponibilidade> horarios = DisponibilidadeStorage.carregar(this);
            for (Disponibilidade item : horarios) {
                if (item.getProfessor().equalsIgnoreCase(nomeAntigo)
                        && item.getCodigoEscola().equalsIgnoreCase(codigoEscola)) {
                    item.setProfessor(nomeNovo);
                }
            }
            DisponibilidadeStorage.salvar(this, horarios);
        }
        ArrayList<Atendimento> atendimentos = AtendimentoStorage.carregar(this);
        for (Atendimento item : atendimentos) {
            if (!item.getCodigoEscola().equalsIgnoreCase(codigoEscola)) continue;
            if (perfil.equals("aluno") && item.getAluno().equalsIgnoreCase(nomeAntigo)) {
                item.setAluno(nomeNovo);
            } else if (perfil.equals("professor")
                    && item.getProfessor().equalsIgnoreCase(nomeAntigo)) {
                item.setProfessor(nomeNovo);
            }
        }
        AtendimentoStorage.salvar(this, atendimentos);
    }

    private void carregarResumo(String perfil, String nomeSessao) {
        if (perfil.equals("aluno")) {
            int pedidos = 0;
            for (Atendimento item : AtendimentoStorage.carregar(this)) {
                if (item.getAluno().equalsIgnoreCase(nomeSessao)) pedidos++;
            }
            resumo.setText(pedidos + (pedidos == 1
                    ? " atendimento solicitado" : " atendimentos solicitados"));
        } else if (perfil.equals("professor")) {
            int horarios = 0;
            for (Disponibilidade item : DisponibilidadeStorage.carregar(this)) {
                if (item.getProfessor().equalsIgnoreCase(nomeSessao)) horarios++;
            }
            int pedidos = 0;
            for (Atendimento item : AtendimentoStorage.carregar(this)) {
                if (item.getProfessor().equalsIgnoreCase(nomeSessao)) pedidos++;
            }
            resumo.setText(horarios + (horarios == 1 ? " horário publicado  ·  " : " horários publicados  ·  ")
                    + pedidos + (pedidos == 1 ? " solicitação" : " solicitações"));
        } else {
            String codigo = getSharedPreferences("eduschedule", MODE_PRIVATE)
                    .getString("codigoEscola", "");
            int alunos = UsuarioStorage.contar(this, codigo, "aluno");
            int professores = UsuarioStorage.contar(this, codigo, "professor");
            int atendimentos = 0;
            for (Atendimento item : AtendimentoStorage.carregar(this)) {
                if (item.getCodigoEscola().equalsIgnoreCase(codigo)) atendimentos++;
            }
            resumo.setText(alunos + (alunos == 1 ? " aluno" : " alunos") + "  ·  "
                    + professores + (professores == 1 ? " professor" : " professores") + "  ·  "
                    + atendimentos + (atendimentos == 1 ? " atendimento" : " atendimentos"));
        }
    }

    private void configurarNavegacao() {
        String perfil = getSharedPreferences("eduschedule", MODE_PRIVATE).getString("perfil", "aluno");
        View navAgendar = findViewById(R.id.navAgendar);
        View navProfessor = findViewById(R.id.navResultados);
        TextView navPerfil = findViewById(R.id.navPerfil);
        if (perfil.equals("aluno")) {
            navProfessor.setVisibility(View.GONE);
            ((TextView) navAgendar).setText("Agendar");
            ((TextView) findViewById(R.id.navHistorico)).setText("Meus");
            ((TextView) navAgendar).setTextColor(getColor(R.color.green));
            navAgendar.setOnClickListener(v -> startActivity(
                    new Intent(this, NovaAtendimentoActivity.class)));
        } else if (perfil.equals("professor")) {
            navAgendar.setVisibility(View.GONE);
            ((TextView) navProfessor).setText("Horários");
            ((TextView) findViewById(R.id.navHistorico)).setText("Pedidos");
            ((TextView) navProfessor).setTextColor(getColor(R.color.green));
            navProfessor.setOnClickListener(v -> startActivity(
                    new Intent(this, ResultadosActivity.class)));
        } else {
            navAgendar.setVisibility(View.GONE);
            navProfessor.setVisibility(View.GONE);
            ((TextView) findViewById(R.id.navHistorico)).setText("Pedidos");
        }
        navPerfil.setText("Perfil");
        navPerfil.setTextColor(getColor(R.color.green));
        findViewById(R.id.navInicio).setOnClickListener(v ->
                startActivity(new Intent(this, MainActivity.class)));
        findViewById(R.id.navHistorico).setOnClickListener(v ->
                startActivity(new Intent(this, HistoricoActivity.class)));
        navPerfil.setOnClickListener(v -> { });
    }

    private String iniciais(String nome) {
        String valorNome = nome == null ? "" : nome.trim();
        if (valorNome.isEmpty()) return "--";
        String[] partes = valorNome.split("\\s+");
        String valor = partes[0].substring(0, 1);
        if (partes.length > 1) valor += partes[partes.length - 1].substring(0, 1);
        return valor.toUpperCase(java.util.Locale.ROOT);
    }

    private String rotulo(String perfil) {
        if (perfil.equals("professor")) return "Professor";
        if (perfil.equals("escola")) return "Administrador da escola";
        return "Aluno";
    }
}
