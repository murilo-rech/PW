package br.edu.ifsul.projetofinalpdm;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;

public class NovaAtendimentoActivity extends AppCompatActivity {
    private Spinner spinnerMateria, spinnerProfessor, spinnerHorario;
    private EditText assunto;
    private TextView resumo;
    private final ArrayList<String> materias = new ArrayList<>();
    private final ArrayList<String> professores = new ArrayList<>();
    private final ArrayList<Disponibilidade> horarios = new ArrayList<>();
    private final ArrayList<Disponibilidade> horariosPublicados = new ArrayList<>();
    private final ArrayList<Atendimento> atendimentos = new ArrayList<>();
    private Disponibilidade horarioSelecionado;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_novo_atendimento);
        ((TextView) findViewById(R.id.txtTituloHeader)).setText("Agendar atendimento");
        spinnerMateria = findViewById(R.id.spinnerMateria);
        spinnerProfessor = findViewById(R.id.spinnerProfessor);
        spinnerHorario = findViewById(R.id.spinnerHorario);
        assunto = findViewById(R.id.edtAssunto);
        resumo = findViewById(R.id.txtResumoHorario);

        spinnerMateria.setOnItemSelectedListener(new SelecionarMateria());
        spinnerProfessor.setOnItemSelectedListener(new SelecionarProfessor());
        spinnerHorario.setOnItemSelectedListener(new SelecionarHorario());
        findViewById(R.id.btnSolicitarAtendimento).setOnClickListener(v -> agendar());
        configurarNavegacao();
    }

    private ArrayList<Disponibilidade> carregarHorariosDisponiveis() {
        ArrayList<Disponibilidade> disponiveis = new ArrayList<>();
        for (Disponibilidade item : horariosPublicados) {
            int ocupadas = 0;
            for (Atendimento atendimento : atendimentos) {
                if (atendimento.getDisponibilidadeId().equals(item.getId())
                        && !atendimento.getStatus().equals("Recusado")) ocupadas++;
            }
            if (ocupadas < item.getVagas()) disponiveis.add(item);
        }
        return disponiveis;
    }

    private void carregarMaterias() {
        materias.clear();
        for (Disponibilidade item : carregarHorariosDisponiveis()) {
            if (!materias.contains(item.getMateria())) materias.add(item.getMateria());
        }
        preencherSpinner(spinnerMateria, materias, "Nenhuma disciplina com vaga");
        atualizarProfessores();
    }

    private void atualizarProfessores() {
        professores.clear();
        String materiaEscolhida = spinnerMateria.getSelectedItem() == null ? ""
                : spinnerMateria.getSelectedItem().toString();
        for (Disponibilidade item : carregarHorariosDisponiveis()) {
            if (item.getMateria().equals(materiaEscolhida) && !professores.contains(item.getProfessor())) {
                professores.add(item.getProfessor());
            }
        }
        preencherSpinner(spinnerProfessor, professores, "Nenhum professor disponível");
        atualizarHorarios();
    }

    private void atualizarHorarios() {
        horarios.clear();
        String materiaEscolhida = spinnerMateria.getSelectedItem() == null ? ""
                : spinnerMateria.getSelectedItem().toString();
        String professorEscolhido = spinnerProfessor.getSelectedItem() == null ? ""
                : spinnerProfessor.getSelectedItem().toString();
        for (Disponibilidade item : carregarHorariosDisponiveis()) {
            if (item.getMateria().equals(materiaEscolhida)
                    && item.getProfessor().equals(professorEscolhido)) horarios.add(item);
        }
        ArrayList<String> opcoes = new ArrayList<>();
        for (Disponibilidade item : horarios) opcoes.add(item.toString());
        preencherSpinner(spinnerHorario, opcoes, "Nenhum horário disponível");
        atualizarResumo();
    }

    private void preencherSpinner(Spinner spinner, ArrayList<String> itens, String vazio) {
        ArrayList<String> opcoes = new ArrayList<>(itens);
        if (opcoes.isEmpty()) opcoes.add(vazio);
        ArrayAdapter<String> adapterSpinner = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_item, opcoes);
        adapterSpinner.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapterSpinner);
    }

    private void atualizarResumo() {
        horarioSelecionado = null;
        int posicao = spinnerHorario.getSelectedItemPosition();
        if (posicao >= 0 && posicao < horarios.size()) {
            horarioSelecionado = horarios.get(posicao);
            int restantes = vagasRestantes(horarioSelecionado);
            resumo.setText(horarioSelecionado.getData() + "  •  "
                    + horarioSelecionado.getInicio() + "–" + horarioSelecionado.getFim()
                    + "\n" + horarioSelecionado.getModalidade() + "  •  " + horarioSelecionado.getLocal()
                    + "\n" + restantes + (restantes == 1 ? " vaga disponível" : " vagas disponíveis"));
        } else {
            resumo.setText("Selecione uma disciplina, um professor e um horário publicado.");
        }
    }

    private int vagasRestantes(Disponibilidade disponibilidade) {
        int ocupadas = 0;
        for (Atendimento item : atendimentos) {
            if (item.getDisponibilidadeId().equals(disponibilidade.getId())
                    && !item.getStatus().equals("Recusado")) ocupadas++;
        }
        return Math.max(0, disponibilidade.getVagas() - ocupadas);
    }

    private void agendar() {
        String motivo = assunto.getText().toString().trim();
        if (horarioSelecionado == null) {
            Toast.makeText(this, "Selecione um horário publicado pelo professor", Toast.LENGTH_SHORT).show();
            return;
        }
        if (motivo.isEmpty()) {
            Toast.makeText(this, "Informe o motivo do atendimento", Toast.LENGTH_SHORT).show();
            return;
        }
        if (vagasRestantes(horarioSelecionado) == 0) {
            carregarMaterias();
            Toast.makeText(this, "Esse horário não tem mais vagas", Toast.LENGTH_LONG).show();
            return;
        }

        String aluno = getSharedPreferences("eduschedule", MODE_PRIVATE).getString("nome", "Aluno");
        for (Atendimento item : atendimentos) {
            if (item.getAluno().equalsIgnoreCase(aluno)
                    && item.getDisponibilidadeId().equals(horarioSelecionado.getId())
                    && !item.getStatus().equals("Recusado")) {
                Toast.makeText(this, "Você já solicitou esse horário", Toast.LENGTH_SHORT).show();
                return;
            }
        }
        String codigoEscola = getSharedPreferences("eduschedule", MODE_PRIVATE)
                .getString("codigoEscola", "");
        atendimentos.add(0, new Atendimento(aluno, horarioSelecionado.getProfessor(),
                horarioSelecionado.getMateria(), horarioSelecionado.getData(),
                horarioSelecionado.getInicio() + "–" + horarioSelecionado.getFim(), motivo,
                "Aguardando confirmação", horarioSelecionado.getId(),
                horarioSelecionado.getModalidade(), horarioSelecionado.getLocal(), codigoEscola));
        AtendimentoStorage.salvar(this, atendimentos);
        Toast.makeText(this, "Agendamento enviado ao professor", Toast.LENGTH_LONG).show();
        startActivity(new Intent(this, HistoricoActivity.class));
    }

    @Override protected void onResume() {
        super.onResume();
        if (spinnerMateria != null) {
            horariosPublicados.clear();
            String codigoEscola = getSharedPreferences("eduschedule", MODE_PRIVATE)
                    .getString("codigoEscola", "");
            for (Disponibilidade item : DisponibilidadeStorage.carregar(this)) {
                if (item.getCodigoEscola().equalsIgnoreCase(codigoEscola)) {
                    horariosPublicados.add(item);
                }
            }
            atendimentos.clear();
            atendimentos.addAll(AtendimentoStorage.carregar(this));
            carregarMaterias();
        }
    }

    private class SelecionarMateria implements AdapterView.OnItemSelectedListener {
        @Override public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
            atualizarProfessores();
        }
        @Override public void onNothingSelected(AdapterView<?> parent) { }
    }

    private class SelecionarProfessor implements AdapterView.OnItemSelectedListener {
        @Override public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
            atualizarHorarios();
        }
        @Override public void onNothingSelected(AdapterView<?> parent) { }
    }

    private class SelecionarHorario implements AdapterView.OnItemSelectedListener {
        @Override public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
            atualizarResumo();
        }
        @Override public void onNothingSelected(AdapterView<?> parent) { }
    }

    private void configurarNavegacao() {
        findViewById(R.id.navInicio).setOnClickListener(v ->
                startActivity(new Intent(this, MainActivity.class)));
        findViewById(R.id.navAgendar).setOnClickListener(v -> { });
        findViewById(R.id.navResultados).setVisibility(View.GONE);
        ((TextView) findViewById(R.id.navAgendar)).setTextColor(getColor(R.color.green));
        findViewById(R.id.navHistorico).setOnClickListener(v ->
                startActivity(new Intent(this, HistoricoActivity.class)));
        ((TextView) findViewById(R.id.navPerfil)).setText("Perfil");
        findViewById(R.id.navPerfil).setOnClickListener(v ->
                startActivity(new Intent(this, MeuPerfilActivity.class)));
    }
}
