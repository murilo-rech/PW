package br.edu.ifsul.projetofinalpdm;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.LinearLayoutManager;
import java.util.ArrayList;
import java.text.SimpleDateFormat;
import java.util.Locale;

public class ResultadosActivity extends AppCompatActivity {
    private final ArrayList<Disponibilidade> lista = new ArrayList<>();
    private final ArrayList<Atendimento> atendimentos = new ArrayList<>();
    private DisponibilidadeAdapter adapter;
    private EditText materia, data, inicio, fim, vagas, local;
    private Spinner modalidade;
    private TextView vazio;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_resultados);
        ((TextView) findViewById(R.id.txtTituloHeader)).setText("Meus horários");
        materia = findViewById(R.id.edtMateriaDisponibilidade);
        data = findViewById(R.id.edtDataDisponibilidade);
        inicio = findViewById(R.id.edtHoraInicio);
        fim = findViewById(R.id.edtHoraFim);
        vagas = findViewById(R.id.edtQuantidadeVagas);
        local = findViewById(R.id.edtLocalAtendimento);
        modalidade = findViewById(R.id.spinnerModalidade);
        vazio = findViewById(R.id.txtSemDisponibilidades);

        ArrayAdapter<String> modos = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_item, new String[]{"Presencial", "Online"});
        modos.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        modalidade.setAdapter(modos);

        RecyclerView recycler = findViewById(R.id.rvDisponibilidades);
        adapter = new DisponibilidadeAdapter(this, lista, atendimentos, vazio);
        recycler.setLayoutManager(new LinearLayoutManager(this));
        recycler.setAdapter(adapter);
        findViewById(R.id.btnPublicarHorario).setOnClickListener(v -> publicar());
        configurarNavegacao();
    }

    private void publicar() {
        String materiaTexto = materia.getText().toString().trim();
        String dataTexto = data.getText().toString().trim();
        String inicioTexto = inicio.getText().toString().trim();
        String fimTexto = fim.getText().toString().trim();
        String vagasTexto = vagas.getText().toString().trim();
        String localTexto = local.getText().toString().trim();
        if (materiaTexto.isEmpty() || dataTexto.isEmpty() || inicioTexto.isEmpty()
                || fimTexto.isEmpty() || vagasTexto.isEmpty() || localTexto.isEmpty()) {
            Toast.makeText(this, "Preencha todos os campos do horário", Toast.LENGTH_SHORT).show();
            return;
        }
        if (!dataValida(dataTexto) || !horaValida(inicioTexto) || !horaValida(fimTexto)) {
            Toast.makeText(this, "Use a data dd/mm/aaaa e horários no formato HH:mm", Toast.LENGTH_LONG).show();
            return;
        }
        if (inicioTexto.compareTo(fimTexto) >= 0) {
            Toast.makeText(this, "O horário final deve ser depois do início", Toast.LENGTH_SHORT).show();
            return;
        }
        int quantidade;
        try {
            quantidade = Integer.parseInt(vagasTexto);
        } catch (NumberFormatException erro) {
            Toast.makeText(this, "Informe uma quantidade de vagas válida", Toast.LENGTH_SHORT).show();
            return;
        }
        if (quantidade < 1) {
            Toast.makeText(this, "O horário precisa ter pelo menos uma vaga", Toast.LENGTH_SHORT).show();
            return;
        }

        String professor = getSharedPreferences("eduschedule", MODE_PRIVATE)
                .getString("nome", "Professor");
        String codigoEscola = getSharedPreferences("eduschedule", MODE_PRIVATE)
                .getString("codigoEscola", "");
        ArrayList<Disponibilidade> todas = DisponibilidadeStorage.carregar(this);
        for (Disponibilidade existente : todas) {
            if (existente.getProfessor().equalsIgnoreCase(professor)
                    && existente.getCodigoEscola().equalsIgnoreCase(codigoEscola)
                    && existente.getData().equals(dataTexto)
                    && inicioTexto.compareTo(existente.getFim()) < 0
                    && fimTexto.compareTo(existente.getInicio()) > 0) {
                Toast.makeText(this, "Esse horário se sobrepõe a outro que você publicou", Toast.LENGTH_LONG).show();
                return;
            }
        }
        Disponibilidade nova = new Disponibilidade(String.valueOf(System.currentTimeMillis()),
                professor, materiaTexto, dataTexto, inicioTexto, fimTexto, quantidade,
                modalidade.getSelectedItem().toString(), localTexto, codigoEscola);
        todas.add(0, nova);
        DisponibilidadeStorage.salvar(this, todas);
        materia.setText("");
        data.setText("");
        inicio.setText("");
        fim.setText("");
        vagas.setText("");
        local.setText("");
        carregarDisponibilidades();
        Toast.makeText(this, "Horário publicado para os alunos", Toast.LENGTH_LONG).show();
    }

    @Override protected void onResume() {
        super.onResume();
        carregarDisponibilidades();
    }

    private void carregarDisponibilidades() {
        if (adapter == null) return;
        atendimentos.clear();
        String codigoEscola = getSharedPreferences("eduschedule", MODE_PRIVATE)
                .getString("codigoEscola", "");
        for (Atendimento item : AtendimentoStorage.carregar(this)) {
            if (item.getCodigoEscola().equalsIgnoreCase(codigoEscola)) atendimentos.add(item);
        }
        lista.clear();
        String professor = getSharedPreferences("eduschedule", MODE_PRIVATE)
                .getString("nome", "Professor");
        for (Disponibilidade item : DisponibilidadeStorage.carregar(this)) {
            if (item.getProfessor().equalsIgnoreCase(professor)
                    && item.getCodigoEscola().equalsIgnoreCase(codigoEscola)) lista.add(item);
        }
        vazio.setVisibility(lista.isEmpty() ? TextView.VISIBLE : TextView.GONE);
        adapter.notifyDataSetChanged();
    }

    private boolean dataValida(String valor) {
        if (!valor.matches("\\d{2}/\\d{2}/\\d{4}")) return false;
        SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault());
        formato.setLenient(false);
        try {
            formato.parse(valor);
            return true;
        } catch (java.text.ParseException erro) {
            return false;
        }
    }

    private boolean horaValida(String valor) {
        if (!valor.matches("\\d{2}:\\d{2}")) return false;
        int hora = Integer.parseInt(valor.substring(0, 2));
        int minuto = Integer.parseInt(valor.substring(3, 5));
        return hora < 24 && minuto < 60;
    }

    private void configurarNavegacao() {
        findViewById(R.id.navAgendar).setVisibility(android.view.View.GONE);
        ((TextView) findViewById(R.id.navResultados)).setText("Horários");
        ((TextView) findViewById(R.id.navHistorico)).setText("Solicitações");
        ((TextView) findViewById(R.id.navPerfil)).setText("Perfil");
        ((TextView) findViewById(R.id.navResultados)).setTextColor(getColor(R.color.green));
        findViewById(R.id.btnVoltar).setOnClickListener(v -> finish());
        findViewById(R.id.navInicio).setOnClickListener(v ->
                startActivity(new Intent(this, MainActivity.class)));
        findViewById(R.id.navResultados).setOnClickListener(v -> { });
        findViewById(R.id.navHistorico).setOnClickListener(v ->
                startActivity(new Intent(this, HistoricoActivity.class)));
        findViewById(R.id.navPerfil).setOnClickListener(v ->
                startActivity(new Intent(this, MeuPerfilActivity.class)));
    }
}
