package br.edu.ifsul.projetofinalpdm;

public class Usuario {
    private String nome;
    private String email;
    private String senha;
    private String perfil;
    private String codigoEscola;
    private String area;
    private String disciplinas;
    private String instituicao;
    private boolean aprovado;

    public Usuario() { }

    public Usuario(String nome, String email, String senha, String perfil,
                   String codigoEscola, String area, String disciplinas, String instituicao) {
        this(nome, email, senha, perfil, codigoEscola, area, disciplinas, instituicao,
                !perfil.equals("professor"));
    }

    public Usuario(String nome, String email, String senha, String perfil,
                   String codigoEscola, String area, String disciplinas, String instituicao,
                   boolean aprovado) {
        this.nome = nome;
        this.email = email;
        this.senha = senha;
        this.perfil = perfil;
        this.codigoEscola = codigoEscola;
        this.area = area;
        this.disciplinas = disciplinas;
        this.instituicao = instituicao;
        this.aprovado = aprovado;
    }

    public String getNome() { return nome == null ? "" : nome; }
    public String getEmail() { return email == null ? "" : email; }
    public String getSenha() { return senha == null ? "" : senha; }
    public String getPerfil() { return perfil == null ? "aluno" : perfil; }
    public String getCodigoEscola() { return codigoEscola == null ? "" : codigoEscola; }
    public String getArea() { return area == null ? "" : area; }
    public String getDisciplinas() { return disciplinas == null ? "" : disciplinas; }
    public String getInstituicao() { return instituicao == null ? "" : instituicao; }
    public boolean isAprovado() { return aprovado; }
    public void setAprovado(boolean aprovado) { this.aprovado = aprovado; }
}
