package br.edu.ifsul.projetofinalpdm;

import android.content.Context;
import android.content.SharedPreferences;
import com.google.gson.Gson;
import java.util.ArrayList;
import java.util.Locale;
import java.util.Map;

public final class UsuarioStorage {
    private UsuarioStorage() { }

    public static Usuario buscar(Context context, String email) {
        String chave = normalizar(email);
        if (chave.isEmpty()) return null;
        String json = preferencias(context).getString(chave, null);
        if (json == null) return null;
        try {
            return new Gson().fromJson(json, Usuario.class);
        } catch (RuntimeException erro) {
            return null;
        }
    }

    public static boolean existe(Context context, String email) {
        String chave = normalizar(email);
        return !chave.isEmpty() && preferencias(context).contains(chave);
    }

    public static boolean salvar(Context context, Usuario usuario, String emailAnterior) {
        String emailNovo = normalizar(usuario.getEmail());
        String chaveAntiga = normalizar(emailAnterior);
        if (emailNovo.isEmpty()) return false;
        SharedPreferences preferencias = preferencias(context);
        if (!emailNovo.equals(chaveAntiga) && preferencias.contains(emailNovo)) return false;
        SharedPreferences.Editor editor = preferencias.edit();
        if (!chaveAntiga.isEmpty() && !chaveAntiga.equals(emailNovo)) editor.remove(chaveAntiga);
        editor.putString(emailNovo, new Gson().toJson(usuario));
        editor.apply();
        return true;
    }

    public static int contar(Context context, String codigoEscola, String perfil) {
        int quantidade = 0;
        for (Usuario usuario : listar(context)) {
            if (usuario.getPerfil().equals(perfil)
                    && usuario.getCodigoEscola().equalsIgnoreCase(codigoEscola)) quantidade++;
        }
        return quantidade;
    }

    public static Usuario buscarEscolaPorCodigo(Context context, String codigoEscola) {
        String codigo = normalizarCodigoEscola(codigoEscola);
        if (codigo.isEmpty()) return null;
        for (Usuario usuario : listar(context)) {
            if (usuario.getPerfil().equals("escola")
                    && normalizarCodigoEscola(usuario.getCodigoEscola()).equals(codigo)) {
                return usuario;
            }
        }
        return null;
    }

    public static boolean codigoEscolaEmUso(Context context, String codigoEscola) {
        return buscarEscolaPorCodigo(context, codigoEscola) != null;
    }

    public static String normalizarCodigoEscola(String codigoEscola) {
        return codigoEscola == null ? "" : codigoEscola.trim().toUpperCase(Locale.ROOT);
    }

    public static boolean formatoCodigoEscolaValido(String codigoEscola) {
        String codigo = normalizarCodigoEscola(codigoEscola);
        return codigo.length() >= 4 && codigo.length() <= 30
                && codigo.matches("[A-Z0-9]+(?:-[A-Z0-9]+)*");
    }

    public static ArrayList<Usuario> professoresPendentes(Context context, String codigoEscola) {
        ArrayList<Usuario> pendentes = new ArrayList<>();
        for (Usuario usuario : listar(context)) {
            if (usuario.getPerfil().equals("professor")
                    && usuario.getCodigoEscola().equalsIgnoreCase(codigoEscola)
                    && !usuario.isAprovado()) pendentes.add(usuario);
        }
        return pendentes;
    }

    public static ArrayList<Usuario> listar(Context context) {
        ArrayList<Usuario> usuarios = new ArrayList<>();
        Map<String, ?> contas = preferencias(context).getAll();
        Gson gson = new Gson();
        for (Object valor : contas.values()) {
            if (!(valor instanceof String)) continue;
            try {
                Usuario usuario = gson.fromJson((String) valor, Usuario.class);
                if (usuario != null) usuarios.add(usuario);
            } catch (RuntimeException erro) {
                // Ignora registros antigos ou incompletos e mantém o restante disponível.
            }
        }
        return usuarios;
    }

    private static SharedPreferences preferencias(Context context) {
        return context.getSharedPreferences("usuarios", Context.MODE_PRIVATE);
    }

    private static String normalizar(String email) {
        return email == null ? "" : email.trim().toLowerCase(Locale.ROOT);
    }
}
